package com.example.hi_bye

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
